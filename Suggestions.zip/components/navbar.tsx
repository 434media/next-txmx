"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, Instagram, ShoppingBag, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"
import { MailIcon } from "./mail-icon"

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <nav className="absolute top-0 left-0 right-0 z-10 w-full">
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(
            to bottom,
            rgba(0, 0, 0, 0.1) 0%,
            rgba(0, 0, 0, 0.05) 30%,
            transparent 100%
          )`,
          backdropFilter: "blur(8px) saturate(1.2)",
          WebkitBackdropFilter: "blur(8px) saturate(1.2)",
        }}
      />
      <div
        className="grain-overlay"
        style={{
          opacity: 0.03,
        }}
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-center">
          <div className="hidden md:flex">
            <div className="flex items-center space-x-4">
              <Link
                href="https://www.instagram.com/txmxboxing/?hl=en"
                target="_blank"
                rel="noopener noreferrer"
                className="group relative"
              >
                <div
                  className="flex items-center px-4 py-3 min-w-[200px] border-2 border-white/30 transition-all duration-300 hover:border-white/60 hover:scale-105"
                  style={{
                    background: "rgba(255, 255, 255, 0.15)",
                    backdropFilter: "blur(12px)",
                    WebkitBackdropFilter: "blur(12px)",
                  }}
                >
                  <div className="flex items-center justify-center w-8 h-8 bg-black mr-3">
                    <Instagram className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-white font-bold text-sm">FOLLOW THE FIGHT</div>
                    <div className="text-white/70 text-xs">@txmxboxing</div>
                  </div>
                  <ExternalLink className="h-4 w-4 text-white/60 ml-2" />
                </div>
              </Link>

              <Link
                href="https://www.434media.com/shop"
                target="_blank"
                rel="noopener noreferrer"
                className="group relative"
              >
                <div
                  className="flex items-center px-4 py-3 min-w-[200px] border-2 border-white/30 transition-all duration-300 hover:border-white/60 hover:scale-105"
                  style={{
                    background: "rgba(255, 255, 255, 0.15)",
                    backdropFilter: "blur(12px)",
                    WebkitBackdropFilter: "blur(12px)",
                  }}
                >
                  <div className="flex items-center justify-center w-8 h-8 bg-black mr-3">
                    <ShoppingBag className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-white font-bold text-sm">GEAR UP</div>
                    <div className="text-white/70 text-xs">Official Store</div>
                  </div>
                  <ExternalLink className="h-4 w-4 text-white/60 ml-2" />
                </div>
              </Link>

              <Link href="mailto:contact@example.com" className="group relative">
                <div
                  className="flex items-center px-4 py-3 min-w-[200px] border-2 border-white/30 transition-all duration-300 hover:border-white/60 hover:scale-105"
                  style={{
                    background: "rgba(255, 255, 255, 0.15)",
                    backdropFilter: "blur(12px)",
                    WebkitBackdropFilter: "blur(12px)",
                  }}
                >
                  <div className="flex items-center justify-center w-8 h-8 bg-black mr-3">
                    <MailIcon size={20} className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-white font-bold text-sm">JOIN THE FIGHT</div>
                    <div className="text-white/70 text-xs">Stay in the ring with us</div>
                  </div>
                  <div className="w-2 h-2 bg-white/60 ml-2"></div>
                </div>
              </Link>
            </div>
          </div>
          <div className="absolute right-0 flex md:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center rounded-md p-2 text-white/80 hover:bg-white/10 hover:text-white focus:outline-none transition-all duration-300"
              style={{
                textShadow: "0 1px 3px rgba(0,0,0,0.5)",
              }}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <span className="sr-only">Open main menu</span>
              {mobileMenuOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={cn("md:hidden", mobileMenuOpen ? "block" : "hidden")}>
        <div
          className="relative flex flex-col items-center space-y-3 px-4 pb-4 pt-3"
          style={{
            background: `linear-gradient(
              to bottom,
              rgba(0, 0, 0, 0.15) 0%,
              rgba(0, 0, 0, 0.1) 50%,
              rgba(0, 0, 0, 0.05) 100%
            )`,
            backdropFilter: "blur(12px) saturate(1.3)",
            WebkitBackdropFilter: "blur(12px) saturate(1.3)",
          }}
        >
          <Link
            href="https://www.instagram.com/txmxboxing/?hl=en"
            target="_blank"
            rel="noopener noreferrer"
            className="group w-full"
            onClick={() => setMobileMenuOpen(false)}
          >
            <div
              className="flex items-center px-4 py-3 w-full border-2 border-white/30 transition-all duration-300 hover:border-white/60"
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                backdropFilter: "blur(12px)",
                WebkitBackdropFilter: "blur(12px)",
              }}
            >
              <div className="flex items-center justify-center w-8 h-8 bg-black mr-3">
                <Instagram className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="text-white font-bold text-sm">FOLLOW THE FIGHT</div>
                <div className="text-white/70 text-xs">@txmxboxing</div>
              </div>
              <ExternalLink className="h-4 w-4 text-white/60 ml-2" />
            </div>
          </Link>

          <Link
            href="https://www.434media.com/shop"
            target="_blank"
            rel="noopener noreferrer"
            className="group w-full"
            onClick={() => setMobileMenuOpen(false)}
          >
            <div
              className="flex items-center px-4 py-3 w-full border-2 border-white/30 transition-all duration-300 hover:border-white/60"
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                backdropFilter: "blur(12px)",
                WebkitBackdropFilter: "blur(12px)",
              }}
            >
              <div className="flex items-center justify-center w-8 h-8 bg-black mr-3">
                <ShoppingBag className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="text-white font-bold text-sm">GEAR UP</div>
                <div className="text-white/70 text-xs">Official Store</div>
              </div>
              <ExternalLink className="h-4 w-4 text-white/60 ml-2" />
            </div>
          </Link>

          <Link href="mailto:contact@example.com" className="group w-full" onClick={() => setMobileMenuOpen(false)}>
            <div
              className="flex items-center px-4 py-3 w-full border-2 border-white/30 transition-all duration-300 hover:border-white/60"
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                backdropFilter: "blur(12px)",
                WebkitBackdropFilter: "blur(12px)",
              }}
            >
              <div className="flex items-center justify-center w-8 h-8 bg-black mr-3">
                <MailIcon size={20} className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="text-white font-bold text-sm">JOIN THE FIGHT</div>
                <div className="text-white/70 text-xs">Stay in the ring with us</div>
              </div>
              <div className="w-2 h-2 bg-white/60 ml-2"></div>
            </div>
          </Link>
        </div>
      </div>
    </nav>
  )
}

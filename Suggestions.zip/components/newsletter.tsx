"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface NewsletterProps {
  onSuccess?: () => void
  compact?: boolean
  mobile?: boolean
}

export function Newsletter({ onSuccess, compact = false, mobile = false }: NewsletterProps) {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSuccess(true)
    setIsSubmitting(false)
    onSuccess?.()

    // Reset after 3 seconds
    setTimeout(() => {
      setIsSuccess(false)
      setEmail("")
    }, 3000)
  }

  if (isSuccess) {
    return (
      <div className="p-6 text-center">
        <h3 className="text-lg font-bold text-black mb-2">Thank You!</h3>
        <p className="text-sm text-gray-700">You've been added to our newsletter.</p>
      </div>
    )
  }

  return (
    <div className={`p-6 ${compact ? "space-y-4" : "space-y-6"}`}>
      <div className="text-center">
        <h3 className="text-lg font-bold text-black mb-2">Stay Updated</h3>
        <p className="text-sm text-gray-700">Get the latest TXMX news and updates.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full"
          disabled={isSubmitting}
        />

        <Button
          type="submit"
          className="w-full bg-black text-white hover:bg-gray-800"
          disabled={isSubmitting || !email}
        >
          {isSubmitting ? "Subscribing..." : "Subscribe"}
        </Button>
      </form>
    </div>
  )
}

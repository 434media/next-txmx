"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, Instagram, ShoppingBag } from "lucide-react"
import { cn } from "@/lib/utils"
import { MailIcon } from "./mail-icon"

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <nav className="absolute top-0 left-0 right-0 z-10 w-full">
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(
            to bottom,
            rgba(0, 0, 0, 0.1) 0%,
            rgba(0, 0, 0, 0.05) 30%,
            transparent 100%
          )`,
          backdropFilter: "blur(8px) saturate(1.2)",
          WebkitBackdropFilter: "blur(8px) saturate(1.2)",
        }}
      />
      <div
        className="grain-overlay"
        style={{
          opacity: 0.03,
        }}
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-center">
          <div className="hidden md:flex">
            <div className="flex items-baseline space-x-6">
              <Link
                href="https://www.instagram.com/txmxboxing/?hl=en"
                target="_blank"
                rel="noopener noreferrer"
                className="group relative px-3 py-2 text-white/90 transition-all duration-300 hover:text-white"
                style={{
                  textShadow: "0 1px 3px rgba(0,0,0,0.5), 0 0 10px rgba(0,0,0,0.3)",
                }}
              >
                <Instagram className="h-5 w-5" />
                <span className="absolute bottom-0 left-0 h-[1px] w-0 bg-white transition-all duration-300 group-hover:w-full"></span>
              </Link>
              <Link
                href="https://www.434media.com/shop"
                target="_blank"
                rel="noopener noreferrer"
                className="group relative px-3 py-2 text-white/90 transition-all duration-300 hover:text-white"
                style={{
                  textShadow: "0 1px 3px rgba(0,0,0,0.5), 0 0 10px rgba(0,0,0,0.3)",
                }}
              >
                <ShoppingBag className="h-5 w-5" />
                <span className="absolute bottom-0 left-0 h-[1px] w-0 bg-white transition-all duration-300 group-hover:w-full"></span>
              </Link>
              <Link
                href="mailto:contact@example.com"
                className="group relative px-3 py-2 text-white/90 transition-all duration-300 hover:text-white"
                style={{
                  textShadow: "0 1px 3px rgba(0,0,0,0.5), 0 0 10px rgba(0,0,0,0.3)",
                }}
              >
                <MailIcon size={20} className="h-5 w-5" />
                <span className="absolute bottom-0 left-0 h-[1px] w-0 bg-white transition-all duration-300 group-hover:w-full"></span>
              </Link>
            </div>
          </div>
          <div className="absolute right-0 flex md:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center rounded-md p-2 text-white/80 hover:bg-white/10 hover:text-white focus:outline-none transition-all duration-300"
              style={{
                textShadow: "0 1px 3px rgba(0,0,0,0.5)",
              }}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <span className="sr-only">Open main menu</span>
              {mobileMenuOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={cn("md:hidden", mobileMenuOpen ? "block" : "hidden")}>
        <div
          className="relative flex flex-col items-center space-y-1 px-2 pb-3 pt-2 text-center sm:px-3"
          style={{
            background: `linear-gradient(
              to bottom,
              rgba(0, 0, 0, 0.15) 0%,
              rgba(0, 0, 0, 0.1) 50%,
              rgba(0, 0, 0, 0.05) 100%
            )`,
            backdropFilter: "blur(12px) saturate(1.3)",
            WebkitBackdropFilter: "blur(12px) saturate(1.3)",
          }}
        >
          <Link
            href="https://www.instagram.com/txmxboxing/?hl=en"
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center rounded-md px-3 py-2 text-base font-medium text-white/90 hover:bg-white/10 hover:text-white transition-all duration-300"
            style={{
              textShadow: "0 1px 3px rgba(0,0,0,0.5)",
            }}
            onClick={() => setMobileMenuOpen(false)}
          >
            <Instagram className="h-5 w-5" />
          </Link>
          <Link
            href="https://www.434media.com/shop"
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center rounded-md px-3 py-2 text-base font-medium text-white/90 hover:bg-white/10 hover:text-white transition-all duration-300"
            style={{
              textShadow: "0 1px 3px rgba(0,0,0,0.5)",
            }}
            onClick={() => setMobileMenuOpen(false)}
          >
            <ShoppingBag className="h-5 w-5" />
          </Link>
          <Link
            href="mailto:contact@example.com"
            className="flex w-full items-center justify-center rounded-md px-3 py-2 text-base font-medium text-white/90 hover:bg-white/10 hover:text-white transition-all duration-300"
            style={{
              textShadow: "0 1px 3px rgba(0,0,0,0.5)",
            }}
            onClick={() => setMobileMenuOpen(false)}
          >
            <MailIcon size={20} className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </nav>
  )
}
